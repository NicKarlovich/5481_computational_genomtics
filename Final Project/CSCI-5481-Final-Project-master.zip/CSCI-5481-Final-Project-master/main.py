from Bio import SeqIO
from simulated_shotgun import SimulatedShotgun

class Main:
    pass


if __name__ == "__main__":
    Main()
