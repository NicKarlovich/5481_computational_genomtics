# Template file for CSCI 5481 Fall 2015 Exercise 1
# Usage:
# template.py -h
import sys, os
import argparse
from subprocess import Popen, PIPE

def make_arg_parser():
    parser = argparse.ArgumentParser(prog='template-python3.py',
                          formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--version', action='version', version='%prog 2.0')
    parser.add_argument("-q","--query",
                      default=argparse.SUPPRESS,
                      required=True,
                      help="Path to query fasta [required]") 
    parser.add_argument("-r","--ref",
                      default=argparse.SUPPRESS,
                      required=True,
                      help="Path to reference fasta [required]")
    parser.add_argument("-t","--taxonomy",
                      default=None,
                      required=True,
                      help="Path to taxonomy file [required]")
    parser.add_argument("-o","--output",
                      default=None,
                      required=True,
                      help="Path to output file [required]")
    parser.add_argument("-c","--command",
                      default='./burst',
                      help="Path to BURST command") 
    parser.add_argument("-V","--verbose",
                      action="store_true",
                      help="Verbose output")
    return parser

# Runs BURST to search query sequences against reference sequences
def run_burst(query, ref, taxonomy, output, burst_cmd='./burst', verbose=False):
	"""thread worker function"""
	# Add "tags" ex. -r, -q, ourselves and combine inputs into a terminal command.
	cmd = burst_cmd + " -r " + ref + " -q " + query + " --taxonomy " + taxonomy + " -o " + output
	return run_command(cmd, verbose=verbose)

# runs the given command and returns return value and output
def run_command(cmd, verbose=False):
	if verbose:
		print(cmd)
	proc = Popen(cmd,shell=True,universal_newlines=True,stdout=PIPE,stderr=PIPE)
	stdout, stderr = proc.communicate()
	return_value = proc.returncode
	return return_value, stdout, stderr

    
if __name__ == '__main__':
	parser = make_arg_parser()
	args = parser.parse_args()
	# YOUR CODE HERE
	# set output of ./burst so that it's saved and can manipulate parts of it
	# rather than just doing print(run_burst(...)) which wont save output of run_burst
	a = run_burst(args.query, args.ref, args.taxonomy, args.output)
	#split up output so it prints cleaner
	print("\n")
	print(a[0])
	print("\n")
	print(a[1])
	print("\n")
	print(a[2])
	
