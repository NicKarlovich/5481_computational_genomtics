To run these files, navigate to the unzipped folder named: karlovich_Homework3/ from your linux based command line
Here you will need python3 to run this code
Once in this directory run the command
> python3 homework3.py -i [name of .fna file]
For example:
> python3 homework3.py -i hw3.fna

Once you run this command the python script will generate the hw3-genetic-distances.txt file for Problem 1 of this homework.
It will also create the preorder traversal file edges.txt and it will generate the post-order traversal file tree.tre. (in the instructions it said tree.txt but the r-script wanted a .tre file instead of a .txt file so that's what I save it as, but you can open a .tre file with something like Notepad++ easily)

To generate the visualization file you need to run the Rscript's that were given in the HW document.  I compiled the final version of my visualization file using the most recently updated .r scripts that Dr. Knights gave us on Monday Nov 4th.